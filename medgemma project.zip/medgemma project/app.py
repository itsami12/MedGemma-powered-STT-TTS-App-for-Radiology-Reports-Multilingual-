from uuid import uuid4
import os
import json
from datetime import datetime
from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from werkzeug.utils import secure_filename
import uvicorn
from pyannote.audio import Pipeline
from transformers import pipeline as stt_pipeline
from pyannote.audio.pipelines.utils.hook import ProgressHook
import torch
from pydub import AudioSegment
import tempfile
from dotenv import load_dotenv
import warnings
import torchaudio
import numpy as np

# Suppress specific warnings
warnings.filterwarnings("ignore", message=".*speechbrain.pretrained.*", category=UserWarning)
warnings.filterwarnings("ignore", message=".*Module 'speechbrain.pretrained' was deprecated.*", category=UserWarning)
warnings.filterwarnings("ignore", message="std(): degrees of freedom is <= 0")
warnings.filterwarnings("ignore", message="The input name `inputs` is deprecated")
warnings.filterwarnings("ignore", message="You have passed task=transcribe, but also have set `forced_decoder_ids`")
warnings.filterwarnings("ignore", message="From v4.47 onwards, when a model cache is to be returned")
warnings.filterwarnings("ignore", message="Whisper did not predict an ending timestamp")

load_dotenv()

# Initialize directories first
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data', 'jsons', 'webspeech')
os.makedirs(DATA_DIR, exist_ok=True)
AUDIO_DIR = os.path.join(BASE_DIR, 'data', 'audio')
os.makedirs(AUDIO_DIR, exist_ok=True)
SEGMENTS_DIR = os.path.join(BASE_DIR, 'data', 'segments')
os.makedirs(SEGMENTS_DIR, exist_ok=True)
WHISPER_DIR = os.path.join(BASE_DIR, 'data', 'jsons', 'whisper')
os.makedirs(WHISPER_DIR, exist_ok=True)
HF_TOKEN = os.getenv('HF_API_KEY')
STT_PIPELINE = os.getenv('STT_PIPELINE')
STT_MODEL_SIZE = os.getenv('STT_MODEL_SIZE')

# Initialize pyannote.audio pipeline before creating FastAPI app
print("Loading speaker diarization model...")
pipeline = Pipeline.from_pretrained(
    "pyannote/speaker-diarization-3.1",
    use_auth_token=HF_TOKEN
)
print("Speaker diarization model loaded")

print('Loading Urdu Whisper model...')
transcriber = stt_pipeline(
    STT_PIPELINE,
    model=STT_MODEL_SIZE,
    device='cuda:0'
)
print("Urdu Whisper model loaded")

print('Loading Silero VAD model...')
vad_model, utils = torch.hub.load(
    repo_or_dir='snakers4/silero-vad',
    model='silero_vad',
    force_reload=False,
    onnx=False
)
(get_speech_timestamps, save_audio, read_audio, VADIterator, collect_chunks) = utils
print("Silero VAD model loaded")

app = FastAPI()

templates = Jinja2Templates(directory=os.path.join(BASE_DIR, 'templates'))

@app.get('/', response_class=HTMLResponse)
async def index(request: Request):
    session_id = str(uuid4())
    return templates.TemplateResponse('index.html', { 'request': request, 'session_id': session_id })


@app.post('/ingest')
async def ingest(payload: dict):
    session_id = payload.get('session_id')
    transcript = payload.get('transcript', '')
    is_final = bool(payload.get('is_final', False))
    ts = payload.get('timestamp') or datetime.utcnow().isoformat() + 'Z'
    if not session_id:
        return JSONResponse({'ok': False, 'error': 'missing session_id'}, status_code=400)
    
    # Use timestamp instead of session_id for filename
    timestamp = datetime.now().strftime('%Y%m%dT%H%M%SZ')
    file_path = os.path.join(DATA_DIR, f'{timestamp}.json')
    
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception:
            data = {'session_id': session_id, 'timestamp': timestamp, 'full_transcript': ''}
    else:
        data = {'session_id': session_id, 'timestamp': timestamp, 'full_transcript': ''}
    if is_final and transcript:
        if data.get('full_transcript'):
            data['full_transcript'] = (data['full_transcript'] + ' ' + transcript).strip()
        else:
            data['full_transcript'] = transcript.strip()
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return { 'ok': True }


@app.post('/upload-audio')
async def upload_audio(session_id: str = Form(...), audio: UploadFile = File(...)):
    if not session_id:
        return JSONResponse({'ok': False, 'error': 'missing session_id'}, status_code=400)
    ts = datetime.now().strftime('%Y%m%dT%H%M%SZ')
    filename = secure_filename(f"{ts}.wav")
    save_path = os.path.join(AUDIO_DIR, filename)
    
    # Read uploaded audio and convert to proper WAV format
    audio_content = await audio.read()
    
    # Create temporary file for conversion
    with tempfile.NamedTemporaryFile(suffix='.webm', delete=False) as temp_file:
        temp_file.write(audio_content)
        temp_path = temp_file.name
    
    try:
        # Convert to WAV using pydub
        audio_segment = AudioSegment.from_file(temp_path, format="webm")
        audio_segment.export(save_path, format="wav", parameters=["-ar", "16000", "-ac", "1"])
        print(f"Audio converted and saved: {save_path}")
    except Exception as e:
        print(f"Error converting audio: {e}")
        return JSONResponse({'ok': False, 'error': f'audio conversion failed: {str(e)}'}, status_code=500)
    finally:
        # Clean up temporary file
        os.unlink(temp_path)
    
    return { 'ok': True, 'file': f'data/audio/{filename}' }


def is_audio_valid_for_transcription(audio_path, min_speech_ratio=0.3, min_duration=0.5):
    """
    Check if audio segment has enough speech content using Silero VAD
    Returns True if audio is worth transcribing, False otherwise
    """
    try:
        # Read audio using torchaudio
        wav, sr = torchaudio.load(audio_path)
        
        # Convert to 16kHz if needed (Silero VAD expects 16kHz)
        if sr != 16000:
            wav = torchaudio.functional.resample(wav, sr, 16000)
        
        # Convert to mono if stereo
        if wav.shape[0] > 1:
            wav = wav.mean(dim=0, keepdim=True)
        
        # Get speech timestamps
        speech_timestamps = get_speech_timestamps(wav, vad_model, sampling_rate=16000)
        
        # Calculate total speech duration
        total_speech_duration = sum((ts['end'] - ts['start']) / 16000 for ts in speech_timestamps)
        total_duration = wav.shape[1] / 16000
        
        # Check if segment has enough speech content
        if total_duration < min_duration:
            return False
            
        speech_ratio = total_speech_duration / total_duration if total_duration > 0 else 0
        
        print(f"  VAD Analysis: {total_speech_duration:.1f}s speech / {total_duration:.1f}s total = {speech_ratio:.1%}")
        
        return speech_ratio >= min_speech_ratio
        
    except Exception as e:
        print(f"  VAD Error: {e} - defaulting to transcribe")
        return True  # Default to transcribing if VAD fails


def transcribe_segments(segment_files, session_folder_name, timestamp):
    """Transcribe individual speaker segments using the pre-loaded Whisper pipeline"""
    print("\n=== Transcribing Speaker Segments ===")
    transcriptions = []
    
    for segment_info in segment_files:
        segment_path = os.path.join(SEGMENTS_DIR, session_folder_name, segment_info['filename'])
        
        # Format timestamp for display
        start_str = f"{int(segment_info['start']//60):02d}:{int(segment_info['start']%60):02d}"
        end_str = f"{int(segment_info['end']//60):02d}:{int(segment_info['end']%60):02d}"
        
        print(f"\n{segment_info['speaker']:<12} {start_str} - {end_str} ({segment_info['duration']:.1f}s)")
        
        # Check audio quality using VAD before transcription
        if not is_audio_valid_for_transcription(segment_path):
            print(f"  Skipped: Low speech content detected")
            segment_info['transcription'] = "[SILENCE/LOW_QUALITY]"
            transcriptions.append(segment_info)
            continue
        
        try:
            # Transcribe using the pre-loaded transformers pipeline with specified parameters
            result = transcriber(
                segment_path,
                return_timestamps=True
            )
            transcription = result["text"].strip()
            
            # Additional quality check: filter out repetitive text
            words = transcription.split()
            if len(words) > 5:
                # Check for excessive repetition (same word > 50% of content)
                word_counts = {}
                for word in words:
                    word_counts[word] = word_counts.get(word, 0) + 1
                max_count = max(word_counts.values()) if word_counts else 0
                repetition_ratio = max_count / len(words)
                
                if repetition_ratio > 0.5:
                    print(f"  Skipped: High repetition detected ({repetition_ratio:.1%})")
                    segment_info['transcription'] = "[REPETITIVE_CONTENT]"
                    transcriptions.append(segment_info)
                    continue
            
            print(f"  Transcription: {transcription}")
            
            # Store transcription
            segment_info['transcription'] = transcription
            transcriptions.append(segment_info)
            
        except Exception as e:
            print(f"  Error transcribing {segment_info['filename']}: {e}")
            segment_info['transcription'] = "[ERROR]"
            transcriptions.append(segment_info)
    
    print("\n" + "=" * 60)
    print("=== Complete Conversation Transcript ===")
    
    # Print final speaker-by-speaker output
    for segment_info in transcriptions:
        start_str = f"{int(segment_info['start']//60):02d}:{int(segment_info['start']%60):02d}"
        end_str = f"{int(segment_info['end']//60):02d}:{int(segment_info['end']%60):02d}"
        print(f"\n{segment_info['speaker']}: [{start_str}-{end_str}] {segment_info['transcription']}")
    
    print("\n" + "=" * 60)
    
    # Save whisper transcription results as JSON
    save_whisper_transcription(transcriptions, timestamp)
    
    return transcriptions


def save_whisper_transcription(transcriptions, timestamp):
    """Save whisper transcription results as JSON"""
    try:
        # Create conversation transcript in structured format
        conversation = {
            'timestamp': timestamp,
            'created_at': datetime.now().isoformat(),
            'total_speakers': len(set(t['speaker'] for t in transcriptions)),
            'total_segments': len(transcriptions),
            'conversation': []
        }
        
        # Add each transcribed segment
        for segment_info in transcriptions:
            conversation['conversation'].append({
                'order': segment_info['order'],
                'speaker': segment_info['speaker'],
                'start_time': segment_info['start'],
                'end_time': segment_info['end'],
                'duration': segment_info['duration'],
                'start_formatted': f"{int(segment_info['start']//60):02d}:{int(segment_info['start']%60):02d}",
                'end_formatted': f"{int(segment_info['end']//60):02d}:{int(segment_info['end']%60):02d}",
                'transcription': segment_info['transcription'],
                'audio_file': segment_info['filename']
            })
        
        # Save to whisper JSON directory
        whisper_file = os.path.join(WHISPER_DIR, f'{timestamp}_transcription.json')
        with open(whisper_file, 'w', encoding='utf-8') as f:
            json.dump(conversation, f, ensure_ascii=False, indent=2)
        
        print(f"Whisper transcription saved: {whisper_file}")
        
    except Exception as e:
        print(f"Error saving whisper transcription: {e}")


def get_next_session_sequence(session_id):
    """Get the next sequential number for this session"""
    session_folders = [f for f in os.listdir(SEGMENTS_DIR) if f.startswith(f"{session_id}_")]
    if not session_folders:
        return "001"
    
    # Extract sequence numbers and find the highest
    sequence_numbers = []
    for folder in session_folders:
        try:
            seq = folder.split('_')[-1]
            if seq.isdigit() and len(seq) == 3:
                sequence_numbers.append(int(seq))
        except:
            continue
    
    if sequence_numbers:
        next_seq = max(sequence_numbers) + 1
        return f"{next_seq:03d}"
    else:
        return "001"


def split_audio_by_segments(audio_path, segments, session_id):
    """Split audio file into individual speaker segments"""
    try:
        # Load the full audio file
        full_audio = AudioSegment.from_wav(audio_path)
        
        # Get timestamp from audio filename
        audio_filename = os.path.basename(audio_path)
        timestamp = audio_filename.replace('.wav', '')
        
        # Create session-based directory with sequential numbering
        sequence = get_next_session_sequence(session_id)
        session_folder_name = f"{session_id}_{sequence}"
        session_segments_dir = os.path.join(SEGMENTS_DIR, session_folder_name)
        os.makedirs(session_segments_dir, exist_ok=True)
        
        # Sort segments by start time to maintain chronological order
        sorted_segments = sorted(segments, key=lambda x: x['start'])
        
        segment_files = []
        
        for i, segment in enumerate(sorted_segments):
            # Extract segment timestamps (convert to milliseconds)
            start_ms = int(segment['start'] * 1000)
            end_ms = int(segment['end'] * 1000)
            
            # Extract the segment from the full audio
            segment_audio = full_audio[start_ms:end_ms]
            
            # Generate filename with chronological order prefix
            speaker = segment['speaker']
            start_time = f"{int(segment['start']//60):02d}{int(segment['start']%60):02d}"
            end_time = f"{int(segment['end']//60):02d}{int(segment['end']%60):02d}"
            segment_filename = f"{i+1:02d}_{speaker}_{start_time}-{end_time}.wav"
            segment_path = os.path.join(session_segments_dir, segment_filename)
            
            # Export segment
            segment_audio.export(segment_path, format="wav")
            segment_files.append({
                'order': i + 1,
                'speaker': speaker,
                'start': segment['start'],
                'end': segment['end'],
                'duration': segment['duration'],
                'filename': segment_filename,
                'path': f'data/segments/{session_folder_name}/{segment_filename}'
            })
            
            print(f"Saved segment {i+1:02d}: {segment_filename}")
        
        return segment_files, session_folder_name
        
    except Exception as e:
        print(f"Error splitting audio: {e}")
        return [], None


@app.post('/diarize')
async def diarize_audio(session_id: str = Form(...)):
    if not session_id:
        return JSONResponse({'ok': False, 'error': 'missing session_id'}, status_code=400)

    # Find the latest audio file (timestamp-based naming)
    audio_files = [f for f in os.listdir(AUDIO_DIR) if f.endswith('.wav')]
    if not audio_files:
        return JSONResponse({'ok': False, 'error': 'no audio file found'}, status_code=404)
    
    latest_audio = sorted(audio_files)[-1]
    audio_path = os.path.join(AUDIO_DIR, latest_audio)
    
    # Extract timestamp from filename (remove .wav extension)
    timestamp = latest_audio.replace('.wav', '')
    
    print(f"\n=== Speaker Diarization Results for Session: {session_id} ===")
    print(f"Audio file: {latest_audio}")
    print(f"Timestamp: {timestamp}")
    print("=" * 60)
    
    try:
        # Run diarization (model is already loaded)
        with ProgressHook() as hook:
            diarization = pipeline(audio_path, hook=hook)
        
        # Extract speaker segments and print to terminal
        segments = []
        merged_segments = []
        
        # First, collect all segments
        for turn, _, speaker in diarization.itertracks(yield_label=True):
            segments.append({
                'speaker': speaker,
                'start': float(turn.start),
                'end': float(turn.end),
                'duration': float(turn.end - turn.start)
            })
        
        # Merge consecutive segments from the same speaker
        if segments:
            current_segment = segments[0].copy()
            
            for segment in segments[1:]:
                # If same speaker and gap is less than 2 seconds, merge
                if (segment['speaker'] == current_segment['speaker'] and 
                    segment['start'] - current_segment['end'] <= 2.0):
                    current_segment['end'] = segment['end']
                    current_segment['duration'] = current_segment['end'] - current_segment['start']
                else:
                    # Add current segment to merged list and start new one
                    merged_segments.append(current_segment)
                    current_segment = segment.copy()
            
            # Add the last segment
            merged_segments.append(current_segment)
        
        # Print merged segments
        for segment in merged_segments:
            start_time = segment['start']
            end_time = segment['end']
            duration = segment['duration']
            
            # Format timestamps
            start_str = f"{int(start_time//60):02d}:{int(start_time%60):02d}"
            end_str = f"{int(end_time//60):02d}:{int(end_time%60):02d}"
            
            print(f"{segment['speaker']:<12} {start_str} - {end_str} ({duration:.1f}s)")
        
        total_speakers = len(set(seg['speaker'] for seg in merged_segments))
        print("=" * 60)
        print(f"Total speakers detected: {total_speakers}")
        print(f"Total segments: {len(merged_segments)} (merged from {len(segments)} original segments)")
        print("=" * 60)
        
        # Split audio into segments
        print("\n=== Splitting Audio into Segments ===")
        segment_files, session_folder_name = split_audio_by_segments(audio_path, merged_segments, session_id)
        print(f"Created {len(segment_files)} audio segments")
        print("=" * 60)
        
        # Transcribe segments using the pre-loaded model
        transcribed_segments = transcribe_segments(segment_files, session_folder_name, timestamp)
        
        # Save complete results including transcriptions
        diarization_file = os.path.join(DATA_DIR, f'{timestamp}_diarization.json')
        with open(diarization_file, 'w', encoding='utf-8') as f:
            json.dump({
                'session_id': session_id,
                'timestamp': timestamp,
                'audio_file': latest_audio,
                'segments': merged_segments,
                'segment_files': transcribed_segments,
                'total_speakers': total_speakers,
                'original_segments_count': len(segments),
                'merged_segments_count': len(merged_segments)
            }, f, ensure_ascii=False, indent=2)
        
        return { 'ok': True, 'message': 'Diarization and transcription completed' }
        
    except Exception as e:
        error_msg = f"Diarization failed: {str(e)}"
        print(f"ERROR: {error_msg}")
        return JSONResponse({'ok': False, 'error': error_msg}, status_code=500)


if __name__ == '__main__':
    print("Starting FastAPI server...")
    uvicorn.run('app:app', host='localhost', port=8000, reload=False)